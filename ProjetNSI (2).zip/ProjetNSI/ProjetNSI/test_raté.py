

def text_to_ascii(text):
    ascii_result = ""
    for char in text:
        if char.isalnum() or char.isspace():
            ascii_result += str(ord(char)) + " "
        else:
            ascii_result += char + " "
    print(f'Text to ASCII: {ascii_result.strip()}')

# Test de la fonction
text_to_ascii("Hello,12134:;,;!,;: World!")

